---
name: "\U0001F48E Angular Material"
about: Issues and feature requests for Angular Material
---

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

Please file any Angular Material issues at: https://github.com/angular/material2/issues/new

For the time being, we keep Angular Material issues in a separate repository.

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑
